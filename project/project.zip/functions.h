#define MAX_LETTERS 7
#define combinations_fname "combinations.txt"
#define words_fname "words.txt"
#define correct_words_fname "correct_words.txt"
void writePossible(const char *numbers, int index);
int isCorrect(const char *numbers);
int writeCorrectWords();